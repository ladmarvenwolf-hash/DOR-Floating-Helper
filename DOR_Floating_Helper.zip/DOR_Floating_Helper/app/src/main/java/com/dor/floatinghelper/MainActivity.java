package com.dor.floatinghelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private DB db;
    private LinearLayout root, list;
    private TextView totals;
    private EditText nameInput, buyInput, sellInput, qtyInput;
    private long editingId = -1;
    private final int pad = 18;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        buildScreen();
        refresh();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad,pad,pad,pad);
        root.setBackgroundColor(0xFFF3F5F8);
        scroll.addView(root);
        TextView title = text("DOR — учёт сделок", 24, true); root.addView(title);
        TextView desc = text("Создавай отдельную вкладку для каждой акции или валюты. Данные сохраняются на устройстве.", 14, false); root.addView(desc);
        totals = text("", 16, true); totals.setPadding(0,16,0,16); root.addView(totals);
        Button add = button("+ Создать вкладку"); add.setOnClickListener(v -> showEditor(null)); root.addView(add);
        TextView h = text("Твои вкладки", 20, true); h.setPadding(0,20,0,8); root.addView(h);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
        setContentView(scroll);
    }

    private void refresh() {
        list.removeAllViews();
        double buys=0, sells=0, net=0;
        SQLiteDatabase d = db.getReadableDatabase();
        Cursor c = d.rawQuery("SELECT id,name,buy,sell,qty FROM trades ORDER BY id DESC", null);
        while(c.moveToNext()) {
            long id=c.getLong(0); String name=c.getString(1); double buy=c.getDouble(2), sell=c.getDouble(3), qty=c.getDouble(4);
            buys += buy; sells += sell; net += afterFees(sell,buy);
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(14,14,14,14); card.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,0,0,12); card.setLayoutParams(cp);
            TextView nm=text(name,19,true); card.addView(nm);
            card.addView(text("Потрачено на покупку: " + money(buy),15,false));
            card.addView(text("Получено от продажи: " + money(sell),15,false));
            card.addView(text("Количество: " + fmt(qty),15,false));
            double netTab=afterFees(sell,buy);
            TextView result=text("Итог после комиссий: " + money(netTab),16,true); result.setTextColor(netTab>=0?0xFF167343:0xFFB3261E); card.addView(result);
            TextView detail=text("Расчёт: покупка +5%, продажа −2%",12,false); detail.setPadding(0,4,0,8); card.addView(detail);
            LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=button("Изменить"); edit.setOnClickListener(v -> showEditor(new Trade(id,name,buy,sell,qty))); actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1));
            Button del=button("Удалить"); del.setOnClickListener(v -> confirmDelete(id,name)); actions.addView(del,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(actions); list.addView(card);
        }
        c.close();
        totals.setText("ОБЩИЙ СЧЁТ\nПотрачено на покупку: " + money(buys) + "\nПолучено от продажи: " + money(sells) + "\nРазница после комиссий: " + money(net));
        if(list.getChildCount()==0) list.addView(text("Пока нет вкладок. Нажми «Создать вкладку».",15,false));
    }

    private double afterFees(double sale, double purchase) { return sale * 0.98 - purchase * 1.05; }

    private void showEditor(Trade t) {
        editingId = t==null ? -1 : t.id;
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(8,4,8,4);
        nameInput = field("Название вкладки (например, Акции)", false);
        buyInput = field("Сумма потраченная на покупку", true);
        sellInput = field("Сумма полученная за продажу", true);
        qtyInput = field("Количество акций или валюты", true);
        form.addView(nameInput); form.addView(buyInput); form.addView(sellInput); form.addView(qtyInput);
        if(t!=null){nameInput.setText(t.name);buyInput.setText(fmt(t.buy));sellInput.setText(fmt(t.sell));qtyInput.setText(fmt(t.qty));}
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(t==null?"Новая вкладка":"Изменить вкладку").setView(form)
            .setNegativeButton("Отмена",(x,w)->{}).setPositiveButton("Сохранить",null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name=nameInput.getText().toString().trim();
            double buy=parse(buyInput.getText().toString()), sell=parse(sellInput.getText().toString()), qty=parse(qtyInput.getText().toString());
            if(name.isEmpty()){nameInput.setError("Укажи название");return;}
            if(buy<0||sell<0||qty<0){Toast.makeText(this,"Введи неотрицательные числа",Toast.LENGTH_SHORT).show();return;}
            ContentValues cv=new ContentValues();cv.put("name",name);cv.put("buy",buy);cv.put("sell",sell);cv.put("qty",qty);cv.put("updated",System.currentTimeMillis());
            if(editingId<0) db.getWritableDatabase().insert("trades",null,cv); else db.getWritableDatabase().update("trades",cv,"id=?",new String[]{String.valueOf(editingId)});
            dialog.dismiss();refresh();
        }));
        dialog.show();
    }

    private void confirmDelete(long id,String name) { new AlertDialog.Builder(this).setTitle("Удалить вкладку?").setMessage("«"+name+"» будет удалена с сохранёнными данными.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{db.getWritableDatabase().delete("trades","id=?",new String[]{String.valueOf(id)});refresh();}).show(); }
    private EditText field(String hint, boolean numeric) { EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setPadding(12,8,12,8);if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);return e; }
    private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xFF17212F);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,5,0,5);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private double parse(String s){try{return Double.parseDouble(s.trim().replace(',','.'));}catch(Exception e){return 0;}}
    private String money(double v){return String.format(Locale.getDefault(),"%,.2f",v);}
    private String fmt(double v){return String.format(Locale.US,"%.4f",v).replaceAll("0+$","").replaceAll("\\.$","");}

    private static class Trade {long id;String name;double buy,sell,qty;Trade(long i,String n,double b,double s,double q){id=i;name=n;buy=b;sell=s;qty=q;}}
    private static class DB extends SQLiteOpenHelper {
        DB(Activity a){super(a,"dor_trades.db",null,1);}
        @Override public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE trades (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, buy REAL NOT NULL DEFAULT 0, sell REAL NOT NULL DEFAULT 0, qty REAL NOT NULL DEFAULT 0, updated INTEGER NOT NULL)");}
        @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
    }
}
