package com.dor.floatinghelper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 1042;
    private static final int CAPTURE_REQUEST = 1043;
    private MediaProjectionManager projectionManager;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24, 24, 24, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(0xFF101820);
        TextView title = new TextView(this); title.setText("DOR • помощник ARZ BANK");
        title.setTextColor(0xFFFFFFFF); title.setTextSize(23); title.setPadding(0,0,0,16); root.addView(title);
        TextView info = new TextView(this);
        info.setText("Панель поверх игры и распознавание видимого текста на экране.\n\nЧтение экрана запускается только после твоего согласия Android. DOR не нажимает кнопки банка и не выполняет сделки. OCR может ошибаться — проверяй цены вручную.");
        info.setTextColor(0xFFE0E6ED); info.setTextSize(15); info.setPadding(0,0,0,18); root.addView(info);
        Button overlay = new Button(this); overlay.setText("Включить плавающую панель");
        overlay.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), OVERLAY_REQUEST);
        } else { startService(new Intent(this, OverlayService.class)); } }); root.addView(overlay);
        Button capture = new Button(this); capture.setText("Включить чтение экрана");
        capture.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) {
            android.widget.Toast.makeText(this, "Сначала разреши показ поверх других приложений", android.widget.Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), OVERLAY_REQUEST);
        } else { startActivityForResult(projectionManager.createScreenCaptureIntent(), CAPTURE_REQUEST); } }); root.addView(capture);
        Button stop = new Button(this); stop.setText("Остановить чтение и панель");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class))); root.addView(stop);
        setContentView(root);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, OverlayService.class));
        } else if (requestCode == CAPTURE_REQUEST && resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, OverlayService.class);
            i.setAction(OverlayService.ACTION_START_CAPTURE);
            i.putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode);
            i.putExtra(OverlayService.EXTRA_RESULT_DATA, data);
            startService(i);
            moveTaskToBack(true);
        }
    }
}
