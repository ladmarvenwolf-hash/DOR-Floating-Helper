package com.dor.floatinghelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
    public static final String ACTION_DB_CHANGED = "com.dor.floatinghelper.DB_CHANGED";
    private DB db; private LinearLayout root,list; private TextView totals; private EditText nameInput,buyInput,sellInput,qtyInput; private long editingId=-1; private final int pad=18;
    private static final int BG=0xFF100B1F, CARD=0xFF211638, PURPLE=0xFF7C4DFF, TEXT=0xFFF4EEFF, MUTED=0xFFBBAED8;
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);getWindow().getDecorView().setBackgroundColor(BG);buildScreen();refresh();}
    @Override protected void onResume(){super.onResume();if(db!=null&&list!=null)refresh();}
    private void notifyChanged(){sendBroadcast(new Intent(ACTION_DB_CHANGED));}
    private void buildScreen(){ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(pad,pad,pad,pad);root.setBackgroundColor(BG);scroll.addView(root);
      TextView title=text("DOR — учёт сделок",24,true);root.addView(title);root.addView(text("Тёмно-фиолетовая панель учёта акций и валюты",14,false));
      Button floating=button("Открыть поверх всех приложений");floating.setOnClickListener(v->enableOverlay());root.addView(floating);
      totals=text("",16,true);totals.setPadding(0,16,0,16);root.addView(totals);Button add=button("+ Создать вкладку");add.setOnClickListener(v->showEditor(null));root.addView(add);
      TextView h=text("Твои вкладки",20,true);h.setPadding(0,20,0,8);root.addView(h);list=new LinearLayout(this);list.setOrientation(1);root.addView(list);setContentView(scroll);}
    private void enableOverlay(){if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));startActivity(i);Toast.makeText(this,"Разреши DOR показываться поверх других приложений, затем вернись сюда и нажми кнопку ещё раз.",Toast.LENGTH_LONG).show();return;}startService(new Intent(this,OverlayService.class));Toast.makeText(this,"Плавающее окно DOR включено",Toast.LENGTH_SHORT).show();}
    private void refresh(){list.removeAllViews();double buys=0,sells=0,net=0;SQLiteDatabase d=db.getReadableDatabase();Cursor c=d.rawQuery("SELECT id,name,buy,sell,qty,buy_fee,sell_fee FROM trades ORDER BY id DESC",null);
      while(c.moveToNext()){long id=c.getLong(0);String name=c.getString(1);double buy=c.getDouble(2),sell=c.getDouble(3),qty=c.getDouble(4),buyFee=c.getDouble(5),sellFee=c.getDouble(6);double purchaseTotal=buy*qty*(1+buyFee/100.0),saleTotal=sell*qty*(1+sellFee/100.0);buys+=purchaseTotal;sells+=saleTotal;net+=saleTotal-purchaseTotal;
       LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(14,14,14,14);card.setBackgroundColor(CARD);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,12);card.setLayoutParams(cp);
       card.addView(text(name,19,true));double n=saleTotal-purchaseTotal;TextView r=text("Итого: "+money(n),16,true);r.setTextColor(n>=0?0xFF72E6B0:0xFFFF7B91);card.addView(r);
       LinearLayout actions=new LinearLayout(this);actions.setOrientation(0);Button edit=button("Изменить");edit.setOnClickListener(v->showEditor(new Trade(id,name,buy,sell,qty,buyFee,sellFee)));actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1));Button del=button("Удалить");del.setOnClickListener(v->confirmDelete(id,name));actions.addView(del,new LinearLayout.LayoutParams(0,-2,1));card.addView(actions);list.addView(card);}
      c.close();totals.setText("ОБЩИЙ СЧЁТ\nПотрачено: "+money(buys)+"\nЗаработаю: "+money(sells)+"\nЧистыми: "+money(net));if(list.getChildCount()==0)list.addView(text("Пока нет вкладок. Нажми Создать вкладку.",15,false));}
    private double afterFees(double sale,double purchase,double qty,double buyFee,double sellFee){return sale*qty*(1+sellFee/100.0)-purchase*qty*(1+buyFee/100.0);}
    private void showEditor(Trade t){editingId=t==null?-1:t.id;LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(8,4,8,4);nameInput=field("Название вкладки",false);buyInput=field("Сумма потраченная на покупку",true);sellInput=field("Сумма полученная за продажу",true);qtyInput=field("Количество акций или валюты",true);EditText buyFeeInput=field("Процент покупки (−10 = минус, +10 = плюс)",true);EditText sellFeeInput=field("Процент продажи (−10 = минус, +10 = плюс)",true);buyFeeInput.setText(t==null?"-5":fmt(t.buyFee));sellFeeInput.setText(t==null?"-2":fmt(t.sellFee));form.addView(nameInput);form.addView(buyInput);form.addView(sellInput);form.addView(qtyInput);form.addView(text("Комиссии для этой вкладки (%)",14,true));form.addView(buyFeeInput);form.addView(sellFeeInput);if(t!=null){nameInput.setText(t.name);buyInput.setText(fmt(t.buy));sellInput.setText(fmt(t.sell));qtyInput.setText(fmt(t.qty));}
      AlertDialog dialog=new AlertDialog.Builder(this).setTitle(t==null?"Новая вкладка":"Изменить вкладку").setView(form).setNegativeButton("Отмена",(x,w)->{}).setPositiveButton("Сохранить",null).create();dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{String name=nameInput.getText().toString().trim();double buy=parse(buyInput.getText().toString()),sell=parse(sellInput.getText().toString()),qty=parse(qtyInput.getText().toString()),buyFee=parse(buyFeeInput.getText().toString()),sellFee=parse(sellFeeInput.getText().toString());if(name.isEmpty()){nameInput.setError("Укажи название");return;}if(buy<0||sell<0||qty<0||buyFee < -100||sellFee < -100||buyFee>100||sellFee>100){Toast.makeText(this,"Цены и количество — неотрицательные; проценты от −100% до +100%",Toast.LENGTH_SHORT).show();return;}ContentValues cv=new ContentValues();cv.put("name",name);cv.put("buy",buy);cv.put("sell",sell);cv.put("qty",qty);cv.put("buy_fee",buyFee);cv.put("sell_fee",sellFee);cv.put("updated",System.currentTimeMillis());if(editingId<0)db.getWritableDatabase().insert("trades",null,cv);else db.getWritableDatabase().update("trades",cv,"id=?",new String[]{String.valueOf(editingId)});dialog.dismiss();refresh();notifyChanged();}));dialog.show();}
    private void confirmDelete(long id,String name){new AlertDialog.Builder(this).setTitle("Удалить вкладку?").setMessage("«"+name+"» будет удалена.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{db.getWritableDatabase().delete("trades","id=?",new String[]{String.valueOf(id)});refresh();notifyChanged();}).show();}
    private EditText field(String hint,boolean numeric){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setPadding(12,8,12,8);if(numeric){e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);installGrouping(e);}return e;}
    private void installGrouping(EditText e){e.addTextChangedListener(new TextWatcher(){boolean changing;public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){}public void afterTextChanged(Editable editable){if(changing)return;String old=editable.toString();int cursor=e.getSelectionStart();String raw=old.replace(".","").replace(" ","");raw=raw.replace('.',',');int comma=raw.indexOf(',');String integer=comma>=0?raw.substring(0,comma):raw;String decimal=comma>=0?raw.substring(comma+1).replace(",",""):"";StringBuilder grouped=new StringBuilder();for(int i=0;i<integer.length();i++){if(i>0&&(integer.length()-i)%3==0)grouped.append('.');grouped.append(integer.charAt(i));}String formatted=grouped.toString()+(comma>=0?","+decimal:"");if(!formatted.equals(old)){changing=true;int diff=formatted.length()-old.length();e.setText(formatted);e.setSelection(Math.max(0,Math.min(formatted.length(),cursor+diff)));changing=false;}}});}
    private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(TEXT);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,5,0,5);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PURPLE));return b;}
    private double parse(String s){try{return Double.parseDouble(s.trim().replace(".","").replace(',','.'));}catch(Exception e){return 0;}}private String money(double v){return String.format(Locale.US,"%.2f",v).replace(',','X').replace('.',',').replace('X','.').replaceAll("(?<=\\d)(?=(\\d{3})+(,|$))", ".");}private String fmt(double v){return String.format(Locale.US,"%.4f",v).replaceAll("0+$","").replaceAll("\\.$","").replace('.',',');}
    private static class Trade{long id;String name;double buy,sell,qty,buyFee,sellFee;Trade(long i,String n,double b,double s,double q,double bf,double sf){id=i;name=n;buy=b;sell=s;qty=q;buyFee=bf;sellFee=sf;}}
    static class DB extends SQLiteOpenHelper{DB(android.content.Context a){super(a,"dor_trades.db",null,3);}@Override public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE trades (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, buy REAL NOT NULL DEFAULT 0, sell REAL NOT NULL DEFAULT 0, qty REAL NOT NULL DEFAULT 0, updated INTEGER NOT NULL, buy_fee REAL NOT NULL DEFAULT -5, sell_fee REAL NOT NULL DEFAULT -2)");}@Override public void onUpgrade(SQLiteDatabase d,int o,int n){if(o<2){d.execSQL("ALTER TABLE trades ADD COLUMN buy_fee REAL NOT NULL DEFAULT -5");d.execSQL("ALTER TABLE trades ADD COLUMN sell_fee REAL NOT NULL DEFAULT -2");}if(o<3){d.execSQL("UPDATE trades SET buy_fee=-ABS(buy_fee), sell_fee=-ABS(sell_fee)");}}}
}
