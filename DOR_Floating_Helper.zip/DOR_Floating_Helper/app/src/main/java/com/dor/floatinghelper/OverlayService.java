package com.dor.floatinghelper;

// Screen capture, OCR and overlay service are intentionally removed in this version.
// The app now uses a persistent local database and a dedicated trade-management screen.
public class OverlayService { }
