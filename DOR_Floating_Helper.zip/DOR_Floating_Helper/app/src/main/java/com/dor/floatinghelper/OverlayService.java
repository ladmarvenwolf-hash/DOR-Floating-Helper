package com.dor.floatinghelper;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.Locale;

public class OverlayService extends Service {
 private WindowManager wm; private View panel; private WindowManager.LayoutParams params; private TextView summary,body; private boolean collapsed=false; private int purple=0xFF8B5CF6, bg=0xFF160D2B, card=0xFF281943, white=0xFFF5EEFF;
 @Override public void onCreate(){super.onCreate();if(!Settings.canDrawOverlays(this)){stopSelf();return;}wm=(WindowManager)getSystemService(WINDOW_SERVICE);createPanel();}
 private void createPanel(){LinearLayout shell=new LinearLayout(this);shell.setOrientation(1);GradientDrawable shape=new GradientDrawable();shape.setColor(bg);shape.setCornerRadius(dp(18));shape.setStroke(dp(1),purple);shell.setBackground(shape);
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(10),dp(5),dp(5),dp(5));header.setBackgroundColor(card);TextView title=new TextView(this);title.setText("✦ DOR  •  ПАНЕЛЬ");title.setTextColor(white);title.setTextSize(15);title.setTypeface(null,Typeface.BOLD);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button fold=small("—");Button close=small("×");header.addView(fold);header.addView(close);shell.addView(header);
  summary=new TextView(this);summary.setTextColor(white);summary.setTextSize(13);summary.setPadding(dp(12),dp(10),dp(12),dp(5));shell.addView(summary);
  body=new TextView(this);body.setTextColor(0xFFD5C7F5);body.setTextSize(12);body.setPadding(dp(12),0,dp(12),dp(8));body.setText("Вкладки и редактирование — в полном окне DOR.");shell.addView(body);
  LinearLayout actions=new LinearLayout(this);actions.setPadding(dp(8),0,dp(8),dp(8));Button open=small("Открыть DOR");open.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);startActivity(i);});actions.addView(open,new LinearLayout.LayoutParams(0,-2,1));Button refresh=small("↻");refresh.setOnClickListener(v->updateSummary());actions.addView(refresh);shell.addView(actions);
  fold.setOnClickListener(v->{collapsed=!collapsed;summary.setVisibility(collapsed?View.GONE:View.VISIBLE);body.setVisibility(collapsed?View.GONE:View.VISIBLE);actions.setVisibility(collapsed?View.GONE:View.VISIBLE);fold.setText(collapsed?"＋":"—");});close.setOnClickListener(v->stopSelf());header.setOnTouchListener(new View.OnTouchListener(){int sx,sy,wx,wy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=(int)e.getRawX();sy=(int)e.getRawY();wx=params.x;wy=params.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=wx+(int)e.getRawX()-sx;params.y=wy+(int)e.getRawY()-sy;wm.updateViewLayout(panel,params);return true;}return e.getAction()==MotionEvent.ACTION_UP;}});
  panel=shell;params=new WindowManager.LayoutParams(dp(300),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.START;params.x=dp(12);params.y=dp(100);wm.addView(panel,params);updateSummary();}
 private void updateSummary(){try{SQLiteDatabase d=new MainActivity.DB(this).getReadableDatabase();Cursor c=d.rawQuery("SELECT COALESCE(SUM(buy),0),COALESCE(SUM(sell),0) FROM trades",null);double b=0,s=0;if(c.moveToFirst()){b=c.getDouble(0);s=c.getDouble(1);}c.close();summary.setText("Покупки: "+money(b)+"\nПродажи: "+money(s)+"\nИтог после комиссий: "+money(s*.98-b*1.05));}catch(Exception e){summary.setText("Открой DOR для начала работы.");}}
 private Button small(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setTextSize(12);b.setMinWidth(dp(36));b.setPadding(dp(5),0,dp(5),0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));return b;}private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}private String money(double v){return String.format(Locale.getDefault(),"%,.2f",v);}
 @Override public int onStartCommand(Intent i,int f,int id){updateSummary();return START_STICKY;}@Override public void onDestroy(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}super.onDestroy();}@Override public IBinder onBind(Intent i){return null;}
}
