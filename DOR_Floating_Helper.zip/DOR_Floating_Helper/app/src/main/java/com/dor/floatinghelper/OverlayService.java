package com.dor.floatinghelper;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class OverlayService extends Service {
 private WindowManager wm; private View panel; private WindowManager.LayoutParams params; private LinearLayout shell, list, editor, actions; private TextView summary, title; private EditText nameField,buyField,sellField,qtyField; private boolean collapsed=false, editorVisible=false; private long editingId=-1; private int purple=0xFF8B5CF6, bg=0xFF160D2B, card=0xFF281943, white=0xFFF5EEFF, muted=0xFFD5C7F5;
 private final BroadcastReceiver changes = new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){refreshAll();}};
 @Override public void onCreate(){super.onCreate();if(!Settings.canDrawOverlays(this)){stopSelf();return;}wm=(WindowManager)getSystemService(WINDOW_SERVICE);registerReceiver(changes,new IntentFilter(MainActivity.ACTION_DB_CHANGED));createPanel();}
 private void createPanel(){
  shell=new LinearLayout(this);shell.setOrientation(1);shell.setPadding(dp(7),dp(7),dp(7),dp(7));GradientDrawable shape=new GradientDrawable();shape.setColor(bg);shape.setCornerRadius(dp(18));shape.setStroke(dp(1),purple);shell.setBackground(shape);
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(8),dp(4),dp(4),dp(4));header.setBackgroundColor(card);title=new TextView(this);title.setText("✦ DOR • ПАНЕЛЬ СДЕЛОК");title.setTextColor(white);title.setTextSize(14);title.setTypeface(null,Typeface.BOLD);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button fold=small("—"),close=small("×");header.addView(fold);header.addView(close);shell.addView(header);
  title.setOnTouchListener(new View.OnTouchListener(){int sx,sy,wx,wy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=(int)e.getRawX();sy=(int)e.getRawY();wx=params.x;wy=params.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=wx+(int)e.getRawX()-sx;params.y=wy+(int)e.getRawY()-sy;try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}return true;}return e.getAction()==MotionEvent.ACTION_UP;}});
  summary=new TextView(this);summary.setTextColor(white);summary.setTextSize(13);summary.setPadding(dp(8),dp(8),dp(8),dp(8));shell.addView(summary);
  Button add=small("+ Новая вкладка");add.setOnClickListener(v->showEditor(null));shell.addView(add);
  editor=new LinearLayout(this);editor.setOrientation(1);editor.setPadding(dp(7),dp(6),dp(7),dp(6));editor.setBackgroundColor(card);shell.addView(editor);editor.setVisibility(View.GONE);
  ScrollView scroller=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(1);scroller.addView(list);shell.addView(scroller,new LinearLayout.LayoutParams(-1,dp(280)));
  actions=new LinearLayout(this);actions.setPadding(0,dp(4),0,0);Button open=small("Полное приложение"),refresh=small("↻ Обновить");open.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);startActivity(i);});refresh.setOnClickListener(v->refreshAll());actions.addView(open,new LinearLayout.LayoutParams(0,-2,1));actions.addView(refresh,new LinearLayout.LayoutParams(0,-2,1));shell.addView(actions);
  fold.setOnClickListener(v->{collapsed=!collapsed;summary.setVisibility(collapsed?View.GONE:View.VISIBLE);scroller.setVisibility(collapsed?View.GONE:View.VISIBLE);add.setVisibility(collapsed?View.GONE:View.VISIBLE);editor.setVisibility(collapsed?View.GONE:(editorVisible?View.VISIBLE:View.GONE));actions.setVisibility(collapsed?View.GONE:View.VISIBLE);fold.setText(collapsed?"＋":"—");});close.setOnClickListener(v->stopSelf());
  int width=Math.min(dp(360),getResources().getDisplayMetrics().widthPixels-dp(20));panel=shell;params=new WindowManager.LayoutParams(width,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.START;params.x=dp(10);params.y=dp(80);wm.addView(panel,params);refreshAll();
 }
 private void refreshAll(){if(shell==null)return;refreshSummary();refreshList();}
 private void refreshSummary(){try{SQLiteDatabase d=new MainActivity.DB(this).getReadableDatabase();Cursor c=d.rawQuery("SELECT COALESCE(SUM(buy),0),COALESCE(SUM(sell),0),COUNT(*) FROM trades",null);double b=0,s=0;int count=0;if(c.moveToFirst()){b=c.getDouble(0);s=c.getDouble(1);count=c.getInt(2);}c.close();summary.setText("Вкладок: "+count+"\nПокупки: "+money(b)+"\nПродажи: "+money(s)+"\nИтог после комиссий: "+money(s*.98-b*1.05));}catch(Exception e){summary.setText("Не удалось прочитать данные. Открой DOR.");}}
 private void refreshList(){if(list==null)return;list.removeAllViews();SQLiteDatabase d=new MainActivity.DB(this).getReadableDatabase();Cursor c=d.rawQuery("SELECT id,name,buy,sell,qty FROM trades ORDER BY id DESC",null);while(c.moveToNext()){long id=c.getLong(0);String name=c.getString(1);double buy=c.getDouble(2),sell=c.getDouble(3),qty=c.getDouble(4);LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(dp(8),dp(6),dp(8),dp(6));GradientDrawable bgShape=new GradientDrawable();bgShape.setColor(card);bgShape.setCornerRadius(dp(10));item.setBackground(bgShape);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.setMargins(0,dp(4),0,dp(4));item.setLayoutParams(ip);TextView nm=label(name,15,true);item.addView(nm);item.addView(label("Покупка: "+money(buy)+" • Продажа: "+money(sell),12,false));item.addView(label("Количество: "+fmt(qty)+" • Итог: "+money(sell*.98-buy*1.05),12,false));LinearLayout row=new LinearLayout(this);Button edit=small("Изменить"),del=small("Удалить");edit.setOnClickListener(v->showEditor(new Trade(id,name,buy,sell,qty)));del.setOnClickListener(v->{new MainActivity.DB(this).getWritableDatabase().delete("trades","id=?",new String[]{String.valueOf(id)});refreshAll();notifyChanged();Toast.makeText(this,"Вкладка удалена",Toast.LENGTH_SHORT).show();});row.addView(edit,new LinearLayout.LayoutParams(0,-2,1));row.addView(del,new LinearLayout.LayoutParams(0,-2,1));item.addView(row);list.addView(item);}c.close();if(list.getChildCount()==0)list.addView(label("Пока нет вкладок. Нажми «Новая вкладка».",12,false));}
 private void showEditor(Trade t){editingId=t==null?-1:t.id;editorVisible=true;editor.removeAllViews();editor.addView(label(t==null?"Новая вкладка":"Изменить вкладку",15,true));nameField=field("Название вкладки",false);buyField=field("Сумма покупки",true);sellField=field("Сумма продажи",true);qtyField=field("Количество",true);editor.addView(nameField);editor.addView(buyField);editor.addView(sellField);editor.addView(qtyField);if(t!=null){nameField.setText(t.name);buyField.setText(fmt(t.buy));sellField.setText(fmt(t.sell));qtyField.setText(fmt(t.qty));}LinearLayout row=new LinearLayout(this);Button save=small("Сохранить"),cancel=small("Отмена");row.addView(save,new LinearLayout.LayoutParams(0,-2,1));row.addView(cancel,new LinearLayout.LayoutParams(0,-2,1));editor.addView(row);editor.setVisibility(collapsed?View.GONE:View.VISIBLE);save.setOnClickListener(v->saveTrade());cancel.setOnClickListener(v->{editorVisible=false;editor.setVisibility(View.GONE);});}
 private void saveTrade(){String n=nameField.getText().toString().trim();double b=parse(buyField.getText().toString()),s=parse(sellField.getText().toString()),q=parse(qtyField.getText().toString());if(n.isEmpty()){nameField.setError("Укажи название");return;}if(b<0||s<0||q<0){Toast.makeText(this,"Значения не могут быть отрицательными",Toast.LENGTH_SHORT).show();return;}ContentValues cv=new ContentValues();cv.put("name",n);cv.put("buy",b);cv.put("sell",s);cv.put("qty",q);cv.put("updated",System.currentTimeMillis());SQLiteDatabase d=new MainActivity.DB(this).getWritableDatabase();if(editingId<0)d.insert("trades",null,cv);else d.update("trades",cv,"id=?",new String[]{String.valueOf(editingId)});editorVisible=false;editor.setVisibility(View.GONE);refreshAll();notifyChanged();Toast.makeText(this,"Сохранено",Toast.LENGTH_SHORT).show();}
 private void notifyChanged(){sendBroadcast(new Intent(MainActivity.ACTION_DB_CHANGED));}
 private EditText field(String hint,boolean numeric){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(13);e.setTextColor(white);e.setHintTextColor(muted);e.setHint(hint);e.setPadding(dp(8),dp(3),dp(8),dp(3));if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);return e;}
 private TextView label(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(white);t.setPadding(0,dp(2),0,dp(2));if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 private Button small(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setTextSize(11);b.setMinWidth(dp(32));b.setPadding(dp(3),0,dp(3),0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));return b;}
 private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}private double parse(String s){try{return Double.parseDouble(s.trim().replace(',','.'));}catch(Exception e){return 0;}}private String money(double v){return String.format(Locale.getDefault(),"%,.2f",v);}private String fmt(double v){return String.format(Locale.US,"%.4f",v).replaceAll("0+$","").replaceAll("\\.$","");}
 private static class Trade{long id;String name;double buy,sell,qty;Trade(long i,String n,double b,double s,double q){id=i;name=n;buy=b;sell=s;qty=q;}}
 @Override public int onStartCommand(Intent i,int f,int id){refreshAll();return START_STICKY;}
 @Override public void onDestroy(){try{unregisterReceiver(changes);}catch(Exception ignored){}if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
