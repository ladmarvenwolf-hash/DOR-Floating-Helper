package com.dor.floatinghelper;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import java.util.Locale;

public class OverlayService extends Service {
    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private LinearLayout panel;
    private TextView result;
    private boolean expanded = true;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createPanel();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(2, 0xFF42C7A5);
        return d;
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setPadding(8, 6, 8, 6);
        return t;
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFFB7C4CE);
        e.setTextSize(14);
        e.setPadding(8, 4, 8, 4);
        e.setBackground(bg(0xFF263642, 8));
        return e;
    }

    private void createPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(10, 8, 10, 10);
        panel.setBackground(bg(0xF216222B, 18));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("DOR • ПОМОЩНИК", 16);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button collapse = new Button(this);
        collapse.setText("—");
        collapse.setMinWidth(44);
        collapse.setOnClickListener(v -> toggleExpanded());
        header.addView(collapse);
        Button close = new Button(this);
        close.setText("×");
        close.setMinWidth(44);
        close.setOnClickListener(v -> stopSelf());
        header.addView(close);
        panel.addView(header);

        // Drag by the header.
        header.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x; startY = params.y;
                    touchX = e.getRawX(); touchY = e.getRawY();
                    return true;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int)(e.getRawX() - touchX);
                    params.y = startY + (int)(e.getRawY() - touchY);
                    try { wm.updateViewLayout(panel, params); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(2, 4, 2, 0);

        body.addView(text("Цена покупки", 12));
        EditText buy = field("Цена покупки", "100");
        body.addView(buy);
        body.addView(text("Цена продажи", 12));
        EditText sell = field("Цена продажи", "110");
        body.addView(sell);
        body.addView(text("Количество", 12));
        EditText qty = field("Количество", "1");
        body.addView(qty);
        body.addView(text("Комиссия покупки, %", 12));
        EditText buyFee = field("Комиссия покупки", "5");
        body.addView(buyFee);
        body.addView(text("Комиссия продажи, %", 12));
        EditText sellFee = field("Комиссия продажи", "2");
        body.addView(sellFee);

        Button calc = new Button(this);
        calc.setText("РАССЧИТАТЬ СДЕЛКУ");
        calc.setOnClickListener(v -> calculate(buy, sell, qty, buyFee, sellFee));
        body.addView(calc);

        result = text("Сигнал: введите реальные цены из ARZ BANK.\nДемо-значения не являются котировками.", 13);
        result.setBackground(bg(0xFF263642, 8));
        body.addView(result);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        panel.addView(scroll);

        params = new WindowManager.LayoutParams(
            dp(300), dp(520),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(12);
        params.y = dp(100);
        wm.addView(panel, params);
    }

    private void calculate(EditText buy, EditText sell, EditText qty, EditText buyFee, EditText sellFee) {
        try {
            double b = Double.parseDouble(buy.getText().toString().trim());
            double s = Double.parseDouble(sell.getText().toString().trim());
            double q = Double.parseDouble(qty.getText().toString().trim());
            double bf = Double.parseDouble(buyFee.getText().toString().trim()) / 100.0;
            double sf = Double.parseDouble(sellFee.getText().toString().trim()) / 100.0;
            if (b <= 0 || s < 0 || q <= 0 || bf < 0 || bf >= 1 || sf < 0 || sf >= 1) {
                result.setText("Проверь значения: цена покупки и количество > 0, комиссии от 0 до 99.99%.");
                return;
            }
            double cost = b * q * (1.0 + bf);
            double proceeds = s * q * (1.0 - sf);
            double pnl = proceeds - cost;
            double breakEven = b * (1.0 + bf) / (1.0 - sf);
            String signal = pnl > 0 ? "ПОТЕНЦИАЛЬНАЯ ПРИБЫЛЬ" : (pnl < 0 ? "УБЫТОК" : "БЕЗУБЫТОЧНО");
            result.setText(String.format(Locale.US,
                "Результат: %s\nЗатраты с комиссией: %.2f\nПосле продажи: %.2f\nПрибыль/убыток: %.2f\nЦена безубыточности: %.2f\n\nВажно: это расчёт по введённым данным, не прогноз рынка.",
                signal, cost, proceeds, pnl, breakEven));
        } catch (Exception ex) {
            result.setText("Введи числовые значения цены, количества и комиссий.");
        }
    }

    private void toggleExpanded() {
        expanded = !expanded;
        // Simple collapse behavior: toggle body visibility.
        if (panel.getChildCount() > 1) panel.getChildAt(1).setVisibility(expanded ? View.VISIBLE : View.GONE);
        params.height = expanded ? dp(520) : dp(60);
        try { wm.updateViewLayout(panel, params); } catch (Exception ignored) {}
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
