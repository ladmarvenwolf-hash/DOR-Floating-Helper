package com.dor.floatinghelper;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 1042;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("DOR Floating Helper");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(24);
        title.setPadding(0, 0, 0, 18);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Плавающая панель поверх Arizona RP.\n\nAndroid должен разрешить показ поверх других приложений. Цены пока вводятся вручную: автоматическое чтение ARZ BANK ещё не реализовано.");
        info.setTextColor(0xFFE0E6ED);
        info.setTextSize(16);
        info.setPadding(0, 0, 0, 24);
        root.addView(info);

        Button start = new Button(this);
        start.setText("Разрешить / открыть настройки");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else {
                startOverlay();
            }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Закрыть плавающую панель");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        root.addView(stop);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) {
            // Do not start automatically; user explicitly taps the start button.
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) {
            startOverlay();
        }
    }

    private void startOverlay() {
        startService(new Intent(this, OverlayService.class));
        finish();
    }
}
