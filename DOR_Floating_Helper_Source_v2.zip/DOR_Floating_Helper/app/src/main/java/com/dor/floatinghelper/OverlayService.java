package com.dor.floatinghelper;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.regex.*;

public class OverlayService extends Service {
    public static final String ACTION_START_CAPTURE="dor.START_CAPTURE";
    public static final String EXTRA_RESULT_CODE="result_code", EXTRA_RESULT_DATA="result_data";
    private static final String CHANNEL="dor_screen_reader";
    private WindowManager wm; private WindowManager.LayoutParams params; private LinearLayout panel; private TextView result;
    private EditText buy, sell, qty, buyFee, sellFee;
    private boolean expanded=true, captureRunning=false, processing=false;
    private MediaProjection projection; private VirtualDisplay virtualDisplay; private ImageReader imageReader;
    private TextRecognizer recognizer; private Handler handler; private Runnable captureRunnable;
    private String lastText="";

    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onCreate(){ super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); handler=new Handler(Looper.getMainLooper()); recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS); createPanel(); }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_START_CAPTURE.equals(intent.getAction())) startCapture(intent);
        return START_NOT_STICKY;
    }
    private GradientDrawable bg(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);d.setStroke(2,0xFF42C7A5);return d;}
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(8,6,8,6);return t;}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(8194);e.setHint(hint);e.setText(value);e.setTextColor(Color.WHITE);e.setHintTextColor(0xFFB7C4CE);e.setTextSize(14);e.setPadding(8,4,8,4);e.setBackground(bg(0xFF263642,8));return e;}
    private void createPanel(){
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(8,6,8,8);panel.setBackground(bg(0xF216222B,18));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=text("DOR • ПОМОЩНИК",15);title.setTypeface(null,1);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button collapse=new Button(this);collapse.setText("—");header.addView(collapse,new LinearLayout.LayoutParams(dp(42),dp(42)));collapse.setOnClickListener(v->toggleExpanded());
        Button close=new Button(this);close.setText("×");header.addView(close,new LinearLayout.LayoutParams(dp(42),dp(42)));close.setOnClickListener(v->stopSelf());panel.addView(header);
        header.setOnTouchListener(new View.OnTouchListener(){int sx,sy;float tx,ty;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=params.x;sy=params.y;tx=e.getRawX();ty=e.getRawY();return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=sx+(int)(e.getRawX()-tx);params.y=sy+(int)(e.getRawY()-ty);try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}return true;}return false;}});
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(2,2,2,0);
        body.addView(text("Цена покупки (можно исправить вручную)",11));buy=field("Покупка","100");body.addView(buy);
        body.addView(text("Цена продажи",11));sell=field("Продажа","110");body.addView(sell);
        body.addView(text("Количество",11));qty=field("Количество","1");body.addView(qty);
        body.addView(text("Комиссия покупки, %",11));buyFee=field("Комиссия покупки","5");body.addView(buyFee);
        body.addView(text("Комиссия продажи, %",11));sellFee=field("Комиссия продажи","2");body.addView(sellFee);
        Button calc=new Button(this);calc.setText("РАССЧИТАТЬ");calc.setOnClickListener(v->calculate());body.addView(calc);
        Button read=new Button(this);read.setText("ОБНОВИТЬ ЧТЕНИЕ ЭКРАНА");read.setOnClickListener(v->{if(!captureRunning)result.setText("Сначала включи чтение в главном окне DOR.");else recognizeNext();});body.addView(read);
        result=text("Чтение экрана выключено.
Включи его в главном окне DOR и подтверди запись экрана.",12);result.setBackground(bg(0xFF263642,8));body.addView(result);
        ScrollView scroll=new ScrollView(this);scroll.addView(body);panel.addView(scroll);
        params=new WindowManager.LayoutParams(dp(310),dp(560),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;params.x=dp(12);params.y=dp(70);wm.addView(panel,params);
    }
    private void calculate(){try{double b=number(buy),s=number(sell),q=number(qty),bf=number(buyFee)/100,sf=number(sellFee)/100;if(b<=0||s<0||q<=0||bf<0||bf>=1||sf<0||sf>=1)throw new Exception();double cost=b*q*(1+bf),proceeds=s*q*(1-sf),pnl=proceeds-cost,be=b*(1+bf)/(1-sf);result.setText(String.format(Locale.US,"СИГНАЛ: %s
Прибыль/убыток: %.2f
Цена безубыточности: %.2f

Расчёт по текущим полям, не прогноз.",pnl>0?"ПОТЕНЦИАЛЬНАЯ ПРИБЫЛЬ":pnl<0?"УБЫТОК":"БЕЗ УБЫТОЧНОСТИ",pnl,be));}catch(Exception e){result.setText("Проверь цены, количество и комиссии.");}}
    private double number(EditText e){return Double.parseDouble(e.getText().toString().trim().replace(',','.').replaceAll("[^0-9.\-]",""));}
    private void startCapture(Intent intent){
        int code=intent.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED);Intent data=intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if(code!=Activity.RESULT_OK||data==null){result.setText("Не получено разрешение на чтение экрана.");return;}
        try{startForeground(31,notification());MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);projection=m.getMediaProjection(code,data);
            projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopCapture();}},handler);
            int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels,d=getResources().getDisplayMetrics().densityDpi;
            imageReader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            virtualDisplay=projection.createVirtualDisplay("DORScreenReader",w,h,d,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,imageReader.getSurface(),null,handler);
            captureRunning=true;result.setText("Чтение включено. Открой ARZ BANK; текст распознаётся примерно раз в 2 секунды. Проверь найденные цены.");recognizeNext();
        }catch(Exception e){result.setText("Не удалось начать чтение: "+e.getMessage());stopCapture();}
    }
    private Notification notification(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"DOR чтение экрана",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}return new Notification.Builder(this,CHANNEL).setContentTitle("DOR читает экран").setContentText("Нажми остановить в DOR, чтобы завершить захват").setSmallIcon(android.R.drawable.ic_menu_view).build();}
    private void recognizeNext(){if(!captureRunning||processing||imageReader==null)return;Image image=null;try{image=imageReader.acquireLatestImage();if(image==null){handler.postDelayed(this::recognizeNext,700);return;}processing=true;Image.Plane plane=image.getPlanes()[0];ByteBuffer buffer=plane.getBuffer();int pixelStride=plane.getPixelStride(),rowStride=plane.getRowStride();int rowPadding=rowStride-pixelStride*image.getWidth();Bitmap bitmap=Bitmap.createBitmap(image.getWidth()+rowPadding/pixelStride,image.getHeight(),Bitmap.Config.ARGB_8888);bitmap.copyPixelsFromBuffer(buffer);Bitmap cropped=Bitmap.createBitmap(bitmap,0,0,image.getWidth(),image.getHeight());image.close();image=null;bitmap.recycle();recognizer.process(InputImage.fromBitmap(cropped,0)).addOnSuccessListener(this::onText).addOnFailureListener(e->{result.setText("Ошибка распознавания текста: "+e.getMessage());}).addOnCompleteListener(t->{cropped.recycle();processing=false;if(captureRunning)handler.postDelayed(this::recognizeNext,1800);});}catch(Exception e){if(image!=null)image.close();processing=false;handler.postDelayed(this::recognizeNext,1500);}}
    private void onText(Text text){String raw=text.getText();if(raw==null)raw="";lastText=raw;String low=raw.toLowerCase(Locale.ROOT);StringBuilder out=new StringBuilder();out.append("РАСПОЗНАННЫЙ ТЕКСТ:
");String trimmed=raw.trim();out.append(trimmed.isEmpty()?"Текст не найден — открой экран банка с видимыми ценами.":trimmed.substring(0,Math.min(trimmed.length(),700)));
        Double b=findPrice(low,"покуп", "buy", "купить"),s=findPrice(low,"прод", "sell", "продать");
        if(b!=null){buy.setText(String.format(Locale.US,"%.2f",b));out.append("

Найдена возможная цена ПОКУПКИ: ").append(b).append(" (проверь!)");}
        if(s!=null){sell.setText(String.format(Locale.US,"%.2f",s));out.append("
Найдена возможная цена ПРОДАЖИ: ").append(s).append(" (проверь!)");}
        if(b==null&&s==null)out.append("

Не удалось уверенно связать числа с покупкой/продажей. Введи цены вручную и нажми РАССЧИТАТЬ.");
        out.append("

DOR только распознаёт видимый текст. Это не автоматическая торговля и не прогноз цены.");result.setText(out.toString());if(b!=null&&s!=null)calculate();}
    private Double findPrice(String text,String... keys){String[] lines=text.split("\n");for(String line:lines){boolean match=false;for(String k:keys)if(line.contains(k))match=true;if(match){Matcher m=Pattern.compile("[0-9][0-9., ]{0,15}").matcher(line);Double last=null;while(m.find()){String n=m.group().replace(" ","").replace(",","");try{double v=Double.parseDouble(n);if(v>0)last=v;}catch(Exception ignored){}}if(last!=null)return last;}}return null;}
    private void stopCapture(){captureRunning=false;if(handler!=null&&captureRunnable!=null)handler.removeCallbacks(captureRunnable);try{if(virtualDisplay!=null)virtualDisplay.release();}catch(Exception ignored){}virtualDisplay=null;try{if(imageReader!=null)imageReader.close();}catch(Exception ignored){}imageReader=null;try{if(projection!=null)projection.stop();}catch(Exception ignored){}projection=null;stopForeground(true);}
    private void toggleExpanded(){expanded=!expanded;if(panel.getChildCount()>1)panel.getChildAt(1).setVisibility(expanded?View.VISIBLE:View.GONE);params.height=expanded?dp(560):dp(60);try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onDestroy(){stopCapture();if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}if(recognizer!=null)recognizer.close();super.onDestroy();}
}
